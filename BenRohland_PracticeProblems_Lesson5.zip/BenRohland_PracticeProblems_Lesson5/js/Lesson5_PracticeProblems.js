/*
This is a program that runs 1 of 6 different functions based on what the
user inputs.
*/


//A function that runs 5 different bitwise operations using 2 user given numbers.
function bitwiseOperations(){
  var num1 = parseInt(prompt("What is the first number?"));
  var num2 = parseInt(prompt("What is the second number?"));

  function bitwiseAnd(x, y){
    return x & y;
  }
  function bitwiseOr(x, y){
    return x | y;
  }
  function bitwiseXor(x, y){
    return x ^ y;
  }
  function bitwiseLeft(x, y){
    return x << y;
  }
  function bitwiseRight(x, y){
    return x >> y;
  }

  document.write(num1 + " & " + num2 + " = " + bitwiseAnd(num1, num2) +
  "<br>" + num1 + " | " + num2 + " = " + bitwiseOr(num1, num2) +
  "<br>" + num1 + " ^ " + num2 + " = " + bitwiseXor(num1, num2) +
  "<br>" + num1 + " << " + num2 + " = " + bitwiseLeft(num1, num2) +
  "<br>" + num1 + " >> " + num2 + " = " + bitwiseRight(num1, num2) + "<br>");

  alert("The answers to the bitwise functions are written on the webpage.");

  functionchosen = false;

}

//A function that determines if a user given word is a palindrome.
function determinePalindrome(){

  var word = prompt("Please enter a word to see if it is a palindrome.");

  /*
  Takes the user given word and flips it by converting to an array,
  it then flips the array and converts it back to a string.
  */
  var word2 = word.split("").reverse().join("");

  //If the user's word and the inverse are equal it's a palindrome.
  //If the user's word and the inverse aren't equal it's not a palindrome.
  if(word === word2){
    alert("This word is a palindrome.");
  }
  else{
    alert("This word is not a palindrome.");
  }

  document.write("<br>");
}

//Asks the user for 3 numbers, then orders them from highest to lowest.
function orderNumbers(){

  var number1 = parseInt(prompt("Please enter the first number."));
  var number2 = parseInt(prompt("Please enter the second number."));
  var number3 = parseInt(prompt("Please enter the third number."));

  if (number1 >= number2 && number2 >= number3){
    document.write(number1 + " " + number2 + " " + number3);
  }
  else if (number1 >= number3 && number2 <= number3){
    document.write(number1 + " " + number3 + " " + number2);
  }
  else if (number1 <= number2 && number1 >= number3){
    document.write(number2 + " " + number1 + " " + number3);
  }
  else if (number1 <= number3 && number2 >= number3){
    document.write(number2 + " " + number3 + " " + number1);
  }
  else if (number3 >= number1 && number1 >= number2){
    document.write(number3 + " " + number1 + " " + number2);
  }
  else if (number3 >= number2 && number2 >= number1){
    document.write(number3 + " " + number2 + " " + number1);
  }

  document.write("<br>");
}

//Takes a percent grade given by the user,
//and outputs a letter grade based on the percent given
function calculateGrade(){
  var percentGrade = -1;

  while (percentGrade > 100 || percentGrade < 0){
    var percentGrade = Number(prompt("What percent is the class grade?"));
  }

  switch (true){
    case (percentGrade == 100):
      document.write("The letter grade is an A+" + "<br>");
      break;
    case (percentGrade >= 93):
      document.write("The letter grade is an A" + "<br>");
      break;
    case (percentGrade >= 90):
      document.write("The letter grade is an A-" + "<br>");
      break;
    case (percentGrade >= 87):
      document.write("The letter grade is a B+" + "<br>");
      break;
    case (percentGrade >= 83):
      document.write("The letter grade is a B" + "<br>");
      break;
    case (percentGrade >= 80):
      document.write("The letter grade is a B-" + "<br>");
      break;
    case (percentGrade >= 77):
      document.write("The letter grade is a C+" + "<br>");
      break;
    case (percentGrade >= 73):
      document.write("The letter grade is a C" + "<br>");
      break;
    case (percentGrade >= 70):
      document.write("The letter grade is a C-" + "<br>");
      break;
    case (percentGrade >= 69):
      document.write("The letter grade is a D+" + "<br>");
      break;
    case (percentGrade >= 68):
      document.write("The letter grade is a D" + "<br>");
      break;
    case (percentGrade >= 67):
      document.write("The letter grade is a D-" + "<br>");
      break;
    case (percentGrade < 67):
      document.write("The letter grade is a F" + "<br>");
      break;
  }
}

//Repeats the text "I am awesome as many times as the user wants."
function stringRepeat(){
  var repeats = 0;
  var theText = "I am Awesome." + "<br>";

  while(repeats <= 0){
    repeats = parseInt(prompt("How many Times would you like me to say \"I am Awesome.\"?"));
  }

  document.write(theText.repeat(repeats));
}

//Removes user given text from a user given sentence.
function textRemove(){
  var message1 = "You will need to enter a sentence and then "
  var message2 = "enter the text you would like to be removed from the sentence."
  var message3 = " Every instance of the text will be removed from the sentence."
  alert(message1 + message2 + message3);

  var sentence = prompt("What is the sentence you would like to edit?");

  //Gets the text to be removed from the user and then turns that text into
  // a regular expression to be used with the replace operation.
  var textRemoved = prompt("What text would you like to have removed from the sentence?")
  var textReg = new RegExp(textRemoved, "gi");

  //Replaces the user given text with nothing.
  sentence = sentence.replace(textReg , "");

  document.write(sentence + "<br>");

  alert("The edited sentence is displayed in the webpage.")
}


var functionChosen = false;

var functionChoiceText = "Type \"1\" in the text field to run bitwise \
operations with two different numbers. Type \"2\" in the text field to run a \
function that removes sections of text from a sentence. Type \"3\" in the \
text field to run a function that repeats the text \"I am Awesome\" as many \
times as you want. Type \"4\" in the text field to run a function that \
determines if a word you enter is a palindrome or not. Type \"5\" in the text \
box to run a function that orders three numbers from highest to lowest\(Sorry \
Steve, I know it was supposed to be the other way around but I accidently did \
it this way, sorry \:\(, please don't hurt me... or my grade.\). Type \"6\" \
to run a function that outputs a letter grade for the percent given."

//Will ask for an input unless 1-6 is chosen, once the function runs it will ask again.
while (functionChosen === false){
  var functionChoice = parseInt(prompt(functionChoiceText));

  switch (true){
    case (functionChoice === 1):
      bitwiseOperations();
      break;
    case (functionChoice === 2):
      textRemove();
      break;
    case (functionChoice === 3):
      stringRepeat();
      break;
    case (functionChoice === 4):
      determinePalindrome();
      break;
    case (functionChoice === 5):
      orderNumbers();
      break;
    case (functionChoice === 6):
      calculateGrade();
      break;
    default:
      functionChosen = false;
      break;
  }
}
